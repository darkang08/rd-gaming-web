(() => {
  'use strict';
  const PHONE = '18294295270';
  const dict = {
    es: {
      title:'RD Gaming | Cámaras, Redes y Tecnología en Punta Cana',
      description:'RD Gaming en Punta Cana y Bávaro: cotizaciones de cámaras de seguridad, redes Wi-Fi, mantenimiento tecnológico, consolas y accesorios. Evaluación digital y visita técnica cuando haga falta.',
      skip:'Saltar al contenido principal', brandline:'Soluciones tecnológicas', navServices:'Servicios', navProcess:'Cómo trabajamos', navFaq:'Preguntas', navQuote:'Cotizar <span aria-hidden="true">↗</span>',
      eyebrow:'Punta Cana · Bávaro · Verón',
      heroTitle:'Tu tecnología resuelta. <span>Sin perder tiempo buscando.</span>',
      heroLead:'Cámaras de seguridad, redes Wi‑Fi, soporte técnico y productos gaming. Cuéntanos qué necesitas: evaluamos tu caso digitalmente y coordinamos una visita solo si hace falta.',
      heroQuote:'Solicitar cotización <span aria-hidden="true">↗</span>', heroWhatsApp:'Hablar por WhatsApp <span aria-hidden="true">↗</span>',
      proof1:'Evaluación inicial digital',proof2:'Visitas coordinadas',proof3:'Equipos bajo pedido',quickKicker:'EMPIEZA AQUÍ',quickTitle:'¿Qué necesitas resolver?',quickDesc:'Elige una categoría y prepara tu solicitud.',
      quick1:'Instalar o reparar cámaras',quick2:'Mejorar internet y Wi‑Fi',quick3:'Revisar un equipo',quick4:'Conseguir un producto',quickFoot:'Sin tienda física de atención al público. Coordinamos digitalmente.',
      servicesEyebrow:'SOLUCIONES A TU MEDIDA',servicesTitle:'Servicios que resuelven problemas reales.',servicesIntro:'Para hogares, pequeños negocios y propiedades en la zona este. Cotizamos según el trabajo y la disponibilidad.',
      service1Title:'Cámaras y seguridad',service1Body:'Instalación CCTV, mejoras de sistemas, acceso remoto, diagnóstico y mantenimiento.',
      service2Title:'Redes y Wi‑Fi',service2Body:'Cobertura, routers, switches, VLANs y solución de fallas de conectividad para negocios.',
      service3Title:'Mantenimiento tecnológico',service3Body:'Diagnóstico, configuración y soporte de computadoras, consolas y equipos electrónicos.',
      service4Title:'Gaming y electrónicos',service4Body:'Consolas, controles, accesorios y productos tecnológicos cotizados bajo pedido.',
      serviceAction:'Pedir cotización <span aria-hidden="true">↗</span>',
      processLabel:'UN PROCESO SENCILLO',processTitle:'Primero entendemos. Después cotizamos.',
      step1Title:'Cuéntanos el problema',step1Body:'Indica dónde estás, qué equipo tienes y qué necesitas resolver.',
      step2Title:'Revisamos tu solicitud',step2Body:'Analizamos la información y pedimos datos o fotos si hacen falta.',
      step3Title:'Cotización o visita',step3Body:'Definimos el presupuesto o coordinamos una evaluación presencial.',
      step4Title:'Aprobación y ejecución',step4Body:'Con tu aprobación, coordinamos los equipos y realizamos el servicio.',
      quoteLabel:'HABLEMOS DE TU PROYECTO',quoteTitle:'Dinos qué necesitas. Nosotros preparamos el siguiente paso.',
      quoteIntro:'Completa lo esencial y abre tu solicitud en WhatsApp. Puedes aportar fotos, modelos y detalles cuando conversemos.',
      quoteBenefit1:'Atención inicial por mensaje',quoteBenefit2:'Presupuesto según tu caso',quoteBenefit3:'Visita solo cuando sea necesaria',contactLabel:'WhatsApp actual',
      formCount:'SOLICITUD DE COTIZACIÓN',formSecure:'Sin crear cuenta',fieldName:'Tu nombre *',fieldArea:'Zona del servicio *',fieldService:'¿Qué necesitas? *',fieldDetails:'Describe tu solicitud *',
      namePlaceholder:'Nombre y apellido',areaPlaceholder:'Bávaro, Verón, Punta Cana...',detailsPlaceholder:'Describe el problema, el producto o cuántos equipos necesitas...',detailsHint:'Si conoces el modelo o la cantidad de equipos, inclúyelos.',
      optionChoose:'Selecciona un servicio',optionCctv:'Cámaras y seguridad',optionNetwork:'Redes y Wi‑Fi',optionMaintenance:'Mantenimiento tecnológico',optionGaming:'Gaming y electrónicos',optionOther:'Otra solicitud tecnológica',
      fieldTiming:'¿Para cuándo?',fieldVisit:'¿Necesita visita?',timeFlexible:'Flexible',timeSoon:'Lo antes posible',timeWeek:'Esta semana',timeMonth:'Este mes',
      visitAssess:'Primero revisar a distancia',visitYes:'Probablemente sí',visitProduct:'Solo un producto',
      submit:'Continuar a WhatsApp <span aria-hidden="true">↗</span>',privacy:'Este formulario no guarda tus datos. Se preparará un mensaje; debes pulsar Enviar en WhatsApp para completar la solicitud.',
      faqLabel:'ANTES DE EMPEZAR',faqTitle:'Preguntas frecuentes',faqIntro:'Así trabajamos en RD Gaming.',
      faq1Q:'¿Puedo pedir una cotización sin visitar una tienda?',faq1A:'Sí. Empezamos con tu solicitud digital y coordinamos una visita técnica únicamente cuando la evaluación lo requiere.',
      faq2Q:'¿Publican precios fijos de instalación?',faq2A:'No para trabajos que dependen del lugar, equipo, distancia o complejidad. Revisamos los detalles antes de confirmar un precio.',
      faq3Q:'¿Tienen consolas y accesorios disponibles en tienda?',faq3A:'Trabajamos con solicitudes y productos bajo pedido. Confirmamos disponibilidad, precio y entrega antes de cerrar la compra.',
      faq4Q:'¿En qué zonas pueden atender?',faq4A:'Nos enfocamos en Punta Cana, Bávaro y Verón. La cobertura de otras zonas se confirma según cada solicitud.',
      footerBrand:'Soluciones tecnológicas en Punta Cana. Cotizaciones digitales, productos bajo pedido y atención técnica coordinada.',footerExplore:'Explorar',footerContact:'Contacto',footerVisits:'Sin atención presencial en tienda. Visitas por coordinación.',footerNote:'Precios, disponibilidad, cobertura y fechas sujetos a confirmación.',
      errorName:'Escribe tu nombre (mínimo 2 caracteres).',errorArea:'Indica la zona donde necesitas el servicio.',errorService:'Selecciona un servicio para continuar.',errorDetails:'Describe tu solicitud con al menos 8 caracteres.',
      whatsappHello:'Hola RD Gaming, quiero solicitar una cotización.',whatsappName:'Nombre',whatsappArea:'Zona',whatsappCategory:'Servicio',whatsappDetails:'Detalle',whatsappTiming:'Fecha preferida',whatsappVisit:'Visita técnica',whatsappSource:'Origen',whatsappEnd:'¿Cuál sería el siguiente paso?',
      menuOpen:'Abrir menú',menuClose:'Cerrar menú',copyQuote:'Copiar solicitud como alternativa',copySuccess:'Solicitud copiada. Puedes pegarla en WhatsApp.',copyFailure:'No se pudo copiar automáticamente. Selecciona el texto de tu solicitud.'
    },
    en: {
      title:'RD Gaming | CCTV, Networking & Technology in Punta Cana',
      description:'RD Gaming in Punta Cana and Bávaro: quotes for CCTV, Wi-Fi networking, tech maintenance, consoles and gaming accessories. Digital assessment and on-site visit when needed.',
      skip:'Skip to main content',brandline:'Technology solutions',navServices:'Services',navProcess:'How we work',navFaq:'FAQs',navQuote:'Get a quote <span aria-hidden="true">↗</span>',
      eyebrow:'Punta Cana · Bávaro · Verón',heroTitle:'Technology problems solved. <span>Without the runaround.</span>',
      heroLead:'Security cameras, Wi‑Fi networks, technical support and gaming products. Tell us what you need. We assess requests online first and arrange an on-site visit when necessary.',
      heroQuote:'Request a quote <span aria-hidden="true">↗</span>',heroWhatsApp:'Chat on WhatsApp <span aria-hidden="true">↗</span>',
      proof1:'Digital initial assessment',proof2:'Visits by arrangement',proof3:'Products sourced on request',quickKicker:'GET STARTED',quickTitle:'What do you need help with?',quickDesc:'Choose a category to start your request.',
      quick1:'Install or repair cameras',quick2:'Fix internet and Wi‑Fi',quick3:'Troubleshoot a device',quick4:'Source a product',quickFoot:'No walk-in store. We coordinate requests digitally.',
      servicesEyebrow:'SOLUTIONS FOR YOUR NEEDS',servicesTitle:'Practical technology services.',servicesIntro:'For homes, small businesses and properties in the eastern region. Prices and availability are confirmed per request.',
      service1Title:'CCTV & security',service1Body:'Camera installation, system upgrades, remote access setup, troubleshooting and maintenance.',
      service2Title:'Networks & Wi‑Fi',service2Body:'Wi‑Fi coverage, routers, switches, VLANs and business network troubleshooting.',
      service3Title:'Technology maintenance',service3Body:'Computer, console and electronics diagnosis, configuration, support and maintenance.',
      service4Title:'Gaming & electronics',service4Body:'Consoles, controllers, accessories and technology products sourced to order.',serviceAction:'Request a quote <span aria-hidden="true">↗</span>',
      processLabel:'A SIMPLE PROCESS',processTitle:'First we assess. Then we quote.',
      step1Title:'Tell us what you need',step1Body:'Describe your location, equipment, issue or project.',
      step2Title:'We review the request',step2Body:'We assess the details and request photos or information when needed.',
      step3Title:'Quote or inspection',step3Body:'We prepare a quote or arrange an on-site assessment.',
      step4Title:'Approve and proceed',step4Body:'After approval, we coordinate equipment and service delivery.',
      quoteLabel:'TELL US ABOUT YOUR PROJECT',quoteTitle:'Tell us what you need. We’ll handle the next step.',
      quoteIntro:'Share a few details to prepare your WhatsApp request. We can discuss photos, models and technical details in the chat.',
      quoteBenefit1:'Start by message',quoteBenefit2:'Quote based on your needs',quoteBenefit3:'Site visit only if necessary',contactLabel:'Current WhatsApp',
      formCount:'QUOTE REQUEST',formSecure:'No account needed',fieldName:'Your name *',fieldArea:'Service area *',fieldService:'What do you need? *',fieldDetails:'Describe your request *',
      namePlaceholder:'Full name',areaPlaceholder:'Bávaro, Verón, Punta Cana...',detailsPlaceholder:'Describe the issue, product or number of devices needed...',detailsHint:'Include equipment models and quantities if known.',
      optionChoose:'Choose a service',optionCctv:'CCTV & security',optionNetwork:'Networks & Wi‑Fi',optionMaintenance:'Technology maintenance',optionGaming:'Gaming & electronics',optionOther:'Other technology request',
      fieldTiming:'Preferred timing',fieldVisit:'On-site inspection',timeFlexible:'Flexible',timeSoon:'As soon as possible',timeWeek:'This week',timeMonth:'This month',
      visitAssess:'Assess remotely first',visitYes:'Probably needed',visitProduct:'Product request only',submit:'Continue to WhatsApp <span aria-hidden="true">↗</span>',
      privacy:'This form does not store your details. It prepares a message; you must press Send in WhatsApp to submit your request.',
      faqLabel:'BEFORE YOU START',faqTitle:'Frequently asked questions',faqIntro:'How RD Gaming works.',
      faq1Q:'Can I request a quote without visiting a store?',faq1A:'Yes. We start with your digital request and arrange a technical visit only if the assessment requires one.',
      faq2Q:'Do you publish fixed installation prices?',faq2A:'Not for jobs that depend on equipment, travel, site conditions or complexity. We review the details before confirming a price.',
      faq3Q:'Are consoles and accessories stocked in a store?',faq3A:'We source products to order. We confirm availability, price and delivery before completing a sale.',
      faq4Q:'Which areas do you serve?',faq4A:'We focus on Punta Cana, Bávaro and Verón. Other locations are confirmed individually.',
      footerBrand:'Technology solutions in Punta Cana. Digital quotations, products sourced to order and coordinated technical service.',footerExplore:'Explore',footerContact:'Contact',footerVisits:'No walk-in store. On-site visits by arrangement.',footerNote:'Prices, availability, coverage and appointment times are confirmed individually.',
      errorName:'Enter your name (at least 2 characters).',errorArea:'Enter the area where you need service.',errorService:'Choose a service to continue.',errorDetails:'Describe your request in at least 8 characters.',
      whatsappHello:'Hello RD Gaming, I would like a quotation.',whatsappName:'Name',whatsappArea:'Area',whatsappCategory:'Service',whatsappDetails:'Details',whatsappTiming:'Preferred timing',whatsappVisit:'On-site inspection',whatsappSource:'Source',whatsappEnd:'Please let me know the next steps.',
      menuOpen:'Open menu',menuClose:'Close menu',copyQuote:'Copy request instead',copySuccess:'Request copied. Paste it into WhatsApp.',copyFailure:'Automatic copying was unavailable. Select and copy your request text.'
    }
  };
  let currentLang = 'es';
  const form = document.getElementById('quoteForm');
  const errorBox = document.getElementById('formError');
  const serviceEl = document.getElementById('service');
  const menuToggle = document.getElementById('menuToggle');
  const nav = document.getElementById('mainNav');
  const fields = ['name','area','service','details','timing','visit'];
  const getField = id => document.getElementById(id);
  const current = () => dict[currentLang];
  const readValue = id => getField(id).value.trim();
  const readLabel = id => {
    const element = getField(id);
    return element.options[element.selectedIndex]?.textContent.trim() || '';
  };
  const source = (() => {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('ref') || params.get('utm_source') || '';
    return /^[a-zA-Z0-9_-]{1,32}$/.test(raw) ? raw.toLowerCase() : '';
  })();

  function setLanguage(lang) {
    if (!dict[lang]) return;
    currentLang = lang;
    document.documentElement.lang = lang === 'es' ? 'es-DO' : 'en';
    document.title = current().title;
    document.querySelector('meta[name="description"]').content = current().description;
    document.querySelector('meta[property="og:description"]').content = current().description;
    document.querySelector('meta[property="og:locale"]').content = lang === 'es' ? 'es_DO' : 'en_US';
    document.querySelector('meta[property="og:title"]').content = current().title;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.dataset.i18n;
      if (typeof current()[key] === 'string') el.textContent = current()[key];
    });
    // Trusted, authored translation strings only; no user input is inserted as HTML.
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const key = el.dataset.i18nHtml;
      if (typeof current()[key] === 'string') el.innerHTML = current()[key];
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.dataset.i18nPlaceholder;
      if (typeof current()[key] === 'string') el.placeholder = current()[key];
    });
    document.querySelectorAll('[data-lang]').forEach(el => {
      const selected = el.dataset.lang === lang;
      el.classList.toggle('is-active', selected);
      el.setAttribute('aria-pressed', String(selected));
    });
    errorBox.hidden = true;
    errorBox.textContent = '';
    const isOpen = nav.classList.contains('is-open');
    menuToggle.setAttribute('aria-label', isOpen ? current().menuClose : current().menuOpen);
    document.querySelectorAll('[data-whatsapp-direct]').forEach(a => {
      a.href = 'https://wa.me/' + PHONE + '?text=' + encodeURIComponent(
        lang === 'es' ? 'Hola RD Gaming, necesito una cotización.' : 'Hello RD Gaming, I would like a quotation.'
      );
    });
  }
  document.querySelectorAll('[data-lang]').forEach(btn => {
    btn.addEventListener('click', () => setLanguage(btn.dataset.lang));
  });
  menuToggle.addEventListener('click', () => {
    const opening = !nav.classList.contains('is-open');
    nav.classList.toggle('is-open', opening);
    menuToggle.setAttribute('aria-expanded', String(opening));
    menuToggle.setAttribute('aria-label', opening ? current().menuClose : current().menuOpen);
  });
  document.querySelectorAll('.main-nav a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', current().menuOpen);
  }));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && nav.classList.contains('is-open')) {
      nav.classList.remove('is-open');
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.setAttribute('aria-label', current().menuOpen);
      menuToggle.focus();
    }
  });
  document.querySelectorAll('[data-service]').forEach(link => {
    link.addEventListener('click', () => {
      serviceEl.value = link.dataset.service;
      serviceEl.removeAttribute('aria-invalid');
      serviceEl.classList.remove('is-invalid');
      errorBox.hidden = true;
    });
  });
  fields.forEach(id => {
    const el = getField(id);
    el.addEventListener('input', () => {
      el.classList.remove('is-invalid');
      el.removeAttribute('aria-invalid');
      errorBox.hidden = true;
    });
    el.addEventListener('change', () => {
      el.classList.remove('is-invalid');
      el.removeAttribute('aria-invalid');
      errorBox.hidden = true;
    });
  });
  const copyButton = document.getElementById('copyQuote');
  const copyFeedback = document.getElementById('copyFeedback');

  function validateQuote() {
    const checks = [
      ['name', readValue('name').length >= 2, 'errorName'],
      ['area', readValue('area').length >= 2, 'errorArea'],
      ['service', !!readValue('service'), 'errorService'],
      ['details', readValue('details').length >= 8, 'errorDetails']
    ];
    for (const [id, valid, key] of checks) {
      if (!valid) {
        const el = getField(id);
        el.classList.add('is-invalid');
        el.setAttribute('aria-invalid', 'true');
        errorBox.textContent = current()[key];
        errorBox.hidden = false;
        el.focus();
        return false;
      }
    }
    errorBox.hidden = true;
    return true;
  }

  function quoteMessage() {
    const t = current();
    const lines = [
      t.whatsappHello, '',
      t.whatsappName+': '+readValue('name'),
      t.whatsappArea+': '+readValue('area'),
      t.whatsappCategory+': '+readLabel('service'),
      t.whatsappDetails+': '+readValue('details'),
      t.whatsappTiming+': '+readLabel('timing'),
      t.whatsappVisit+': '+readLabel('visit')
    ];
    if (source) lines.push(t.whatsappSource+': '+source);
    lines.push('',t.whatsappEnd);
    return lines.join('\n');
  }

  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!validateQuote()) return;
    const url = 'https://wa.me/'+PHONE+'?text='+encodeURIComponent(quoteMessage());
    // Same-tab navigation avoids popup blockers and duplicate tabs.
    window.location.assign(url);
  });

  copyButton.addEventListener('click', async () => {
    if (!validateQuote()) return;
    const message = quoteMessage();
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(message);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = message;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.select();
        const ok = document.execCommand('copy');
        textArea.remove();
        if (!ok) throw new Error('Clipboard unavailable');
      }
      copyFeedback.textContent = current().copySuccess;
    } catch (_err) {
      copyFeedback.textContent = current().copyFailure+'\n'+message;
    }
    copyFeedback.hidden = false;
  });
  document.getElementById('year').textContent = String(new Date().getFullYear());
  setLanguage('es');
})();
